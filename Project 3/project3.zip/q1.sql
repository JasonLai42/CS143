SELECT id FROM Laureate WHERE givenName="Marie" AND familyName="Curie";
