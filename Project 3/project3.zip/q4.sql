SELECT COUNT(DISTINCT city, country) FROM Affiliation WHERE affiliationName="University of California";
