SELECT DISTINCT country FROM Affiliation WHERE affiliationName="CERN";
